import discord

class Player(object):
    playerObj = None
    roleName = ""


